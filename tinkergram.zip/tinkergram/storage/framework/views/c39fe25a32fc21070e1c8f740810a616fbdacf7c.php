<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">

            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-3">
                        <?php if(empty($profile->image)): ?>

                        <img class="rounded-circle" width="150" src="<?php echo e(url('/images/profile.png')); ?>">
                        <?php else: ?>:

                        <img class="rounded-circle" width="150" src="/<?php echo e($profile->image); ?>"> 
                        <?php endif; ?>
                    </div>
                    <div class="col-md-9">

                    <h3><?php echo e($user->name); ?></h3>
                    <span><strong><?php echo e($postscount); ?></strong> posts</span>

                    <?php if(empty($profile->description)): ?>

                    <div class="pt-3"><a href="/profile/edit">Add a description to your profile!</a></div>

                    <?php else: ?>:

                    <div class="pt-3"><?php echo e($profile->description); ?></div>
                    <div class="pt-3"><a href="/profile/edit">Edit profile</a></div>

                    <?php endif; ?>

                    </div>

                    <div class="row pt-5">
                            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-4 mb-5">
                                    <a href="/post/<?php echo e($post->id); ?>">
                                        <img src="/<?php echo e($post->image); ?>" class="w-100">
                                    </a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                </div>
                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/ytbryan/Desktop/tinkergram/resources/views/profile.blade.php ENDPATH**/ ?>